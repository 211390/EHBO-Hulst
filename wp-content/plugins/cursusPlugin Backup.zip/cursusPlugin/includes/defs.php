<?php
/**
  * Definitions needed in the plugin
  *
  * @author Colin van der Ende
  * @version 0.1
  *
  * Version history
  * 0.1 Initial version
  */

// De versie moet gelijk zijn met het versie nummer in de my-event-organiser.php header
define( 'CURSUS_PLUGIN_VERSION', '0.0.1' );

// Minimum required WordPress version for this plugin
define('CURSUS_PLUGIN_REQUIRED_WP_VERSION', '4.0');

define('CURSUS_PLUGIN_BASENAME', plugin_basename(CURSUS_PLUGIN));

define('CURSUS_PLUGIN_NAME', trim(dirname(CURSUS_PLUGIN_BASENAME), '/' ));

// Folder structure
define('CURSUS_PLUGIN_DIR', untrailingslashit(dirname(CURSUS_PLUGIN)));

define('CURSUS_PLUGIN_INCLUDES_DIR', CURSUS_PLUGIN_DIR . '/includes');

define('CURSUS_PLUGIN_MODEL_DIR', CURSUS_PLUGIN_INCLUDES_DIR . '/model');

define('CURSUS_PLUGIN_ADMIN_DIR', CURSUS_PLUGIN_DIR . '/admin');

define('CURSUS_PLUGIN_ADMIN_VIEWS_DIR', CURSUS_PLUGIN_ADMIN_DIR . '/views');

define('CURSUS_PLUGIN_INCLUDES_VIEWS_DIR',	CURSUS_PLUGIN_INCLUDES_DIR	.	'/views');

define('CURSUS_PLUGIN_INCLUDES_IMGS_DIR', CURSUS_PLUGIN_INCLUDES_DIR . '/images');

?>
