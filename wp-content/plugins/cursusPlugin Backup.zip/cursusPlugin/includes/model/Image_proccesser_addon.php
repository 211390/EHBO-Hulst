<?php
/**
  * addon for the image proccessor for front-end en back-end goedkeuring
  *
  * @author Colin van der Ende
  */

include CURSUS_PLUGIN_MODEL_DIR . "/newCourseRegistration_processor.php";


class image_proccessor_addon {

  private $images_proccessor = null;
  private $categorie = null;

  public function __construct() {
    $this->Image_processer = new Image_processer();
  }

  /**
    *
    * @return type
    */
  public function getNrOfImages($goedkeuring) {

    return $this->Image_processer->getNrOfImages($goedkeuring);
  }

  public function getImageList($goedkeuring) {

    return $this->Image_processer->getImageList($goedkeuring);
  }

  public function handleGetAction($get_array) {

    return $this->Image_processer->handleGetAction($get_array);
  }

  public function getGetValues() {

    return $this->Image_processer->getGetValues();
  }

  public function getPostValues() {

    return $this->Image_processer->getPostValues();
  }

  public function getId() {

    return $this->Image_processer->getId();
  }

  public function getNaam() {

    return $this->Image_processer->getNaam();
  }

  public function getCategorie() {

    return $this->Image_processer->getCategorie();
  }

  public function getGoedkeuring() {

    return $this->Image_processer->getGoedkeuring();
  }

  public function getCatList() {

    return $this->Image_processer->getCatList();
  }

  public function getCatId() {

    return $this->Image_processer->getCatId();
  }

  public function getCatNaam() {

    return $this->Image_processer->getCatNaam();
  }

  public function getCurrentCatList($current) {

    return $this->Image_processer->getCurrentCatList($current);
  }




  private function getTableName(){

    global $wpdb;
    return $table = $wpdb->prefix . "isw_afbeeldingen";
  }



  public function update($input_array) {
    try {
      $array_fields = array('id', 'afbeelding_naam' , 'categorie', 'goedkeuring');
      $table_fields = array('ID_afbeelding', 'afbeelding_naam', 'FK_ID_categorie', 'goedkeuring');
      $data_array = array();

      // Check fields
      foreach( $array_fields as $field){

        // Check fields
        if (!isset($input_array[$field])){
          throw new Exception(__("$field is mandatory for update."));
        }

        // Add data_array (without hash idx)
        // (input_array is POST data -> Could have more fields)
        $data_array[] = $input_array[$field];
      }
      global $wpdb;
      // Update query
      /*
      $wpdb->query($wpdb->prepare("UPDATE ".$this->getTableName()."
      SET `name` = '%s', `description` = '%s' ".
      "WHERE `wp_meo_event_category`.`id_event_category` =%d;",$input_array['name'],
      $input_array['description'], $input_array['id']) );
      /*/


      // Replace form field id index by table id name
      $wpdb->query($wpdb->prepare("UPDATE " . $this->getTableName() . " SET `afbeelding_naam` = '%s', `FK_ID_categorie` = '%s', `goedkeuring` = '%s' " . "WHERE `wp_isw_afbeeldingen`.`ID_afbeelding` =%d;", $input_array['afbeelding_naam'], $input_array['categorie'], $input_array['goedkeuring'], $input_array['id']));
      //*/
    } catch (Exception $exc) {
      // @todo: Fix error handlin
      echo $exc->getTraceAsString();
      $this->last_error = $exc->getMessage();
      return FALSE;
    }
    return TRUE;
  }
}
