<?php
/**
* image uploader file
*
* @author Colin van der Ende
*/

include CURSUS_PLUGIN_MODEL_DIR . "/newCourseRegistration_processor.php";

class Image_processer {

  private $categorie = null;

  public function __construct() {
    $this->categorie = new categorie_proccessor();
  }

  public function getCatList() {

    return $this->categorie->getCatList();
  }

  public function getCurrentCatList($current) {

    return $this->categorie->getCurrentCatList($current);
  }

  public function getGetValues(){
    // Define the check for params
    $get_check_array = array (

      // Action
      'action'          => array('filter' => FILTER_SANITIZE_STRING ),

      // Id of current row
      'id'              => array('filter' => FILTER_VALIDATE_INT ),

      // afbeelding link
      'link'            => array('filter' => FILTER_SANITIZE_STRING ),

      // naam link
      'naam'            => array('filter' => FILTER_SANITIZE_STRING ),

      // categorie link
      'categorie'       => array('filter' => FILTER_VALIDATE_INT ),

      // goedkeuring link
      'goedkeuring'     => array('filter' => FILTER_VALIDATE_INT )
    );

    // Get filtered input:
    $inputs = filter_input_array( INPUT_GET, $get_check_array );

    // RTS
    return $inputs;

  }

  public function getPostValues(){
    // Define the check for params
    $post_check_array = array (
      // submit action
      'submit' => array('filter' => FILTER_SANITIZE_STRING ),
      'update'   => array('filter' =>FILTER_SANITIZE_STRING ),
      // List all update form fields !!!
      //
      // event type name.
      'afbeelding_naam' => array('filter' => FILTER_SANITIZE_STRING ),
      // Help text
      'fileToUpload' => array('filter' => FILTER_SANITIZE_STRING ),
      // event type name.
      'categorie' => array('filter' => FILTER_SANITIZE_STRING ),
      // Help text
      'goedkeuring' => array('filter' => FILTER_SANITIZE_STRING ),


      // Id of current row
      'id' => array( 'filter' => FILTER_VALIDATE_INT )
    );
    // Get filtered input:
    $inputs = filter_input_array( INPUT_POST, $post_check_array );
    // RTS
    return $inputs;
  }

  /**
  *
  * @param type $id Id of the event category
  */
  public function setId($ID_afbeelding){
    if (is_int(intval($ID_afbeelding))){
      $this->ID_afbeelding = $ID_afbeelding;
    }
  }

  /**
  *
  * @param type $id Id of the event category
  */
  public function setnaam($afbeelding_naam){
    if (is_int(intval($afbeelding_naam))){
      $this->afbeelding_naam = $afbeelding_naam;
    }
  }

  /**
  *
  * @param type $name name of the event category
  */
  public function setAfbeelding($afbeelding_link){
    if (is_string($afbeelding_link)){
      $this->afbeelding_link = trim($afbeelding_link);
    }
  }

  /**
  *
  * @param type $desc The help text of the event category
  */
  public function setCategorie ($FK_ID_categorie){
    if (is_string($FK_ID_categorie)){
      $this->FK_ID_categorie = trim($FK_ID_categorie);
    }
  }

  /**
  *
  * @param type $desc The help text of the event category
  */
  public function setGoedkeuring($goedkeuring) {
    if (is_string($goedkeuring)) {
      $this->goedkeuring = trim($goedkeuring);
    }
  }


  /**
  *
  * @return int
  */
  public function getCatId() {
    return $this->ID_categorie;
  }

  /**
  *
  * @return string
  */
  public function GetCatName() {
    return $this->categorie_naam;
  }

  /**
  *
  * @return int
  */
  public function getId(){
    return $this->ID_afbeelding;
  }

  /**
  *
  * @return string
  */
  public function getNaam(){
    return $this->afbeelding_naam;
  }

  /**
  *
  * @return int
  */
  public function getAfbeelding(){
    return $this->afbeelding_link;
  }

  /**
  *
  * @return int
  */
  public function getCategorie(){
    return $this->FK_ID_categorie;
  }

  /**
  *
  * @return int
  */
  public function getGoedkeuring(){
    return $this->goedkeuring;
  }

  /**
  *
  * @global type $wpdb
  * @return type string table name with wordpress (and app prefix)
  */
  private function getTableName(){

    global $wpdb;
    return $table = $wpdb->prefix . "isw_afbeeldingen";
  }

  /* get all handleGetActions
  *
  *
  */

  public function handleGetAction( $get_array ){
    $action = '';


    switch($get_array['action']){

      case 'update':
      // Indicate current action is update if id provided
      if ( !is_null($get_array['id']) ){
      $action = $get_array['action'];
      }
      break;

      case 'delete':
      // Delete current id if provided
      if ( !is_null($get_array['id']) ){
        $this->delete($get_array);
      }

      $action = 'delete';
      break;
      default:
      // Oops
      break;
    }
    return $action;
  }


  public function getNrOfImages($goedkeuring){
    global $wpdb;

    $query = "SELECT COUNT(*) AS nr FROM `". $wpdb->prefix ."isw_afbeeldingen` WHERE `goedkeuring` = `$goedkeuring`";
    $result = $wpdb->get_results( $query, ARRAY_A );

    return $result[0]['nr'];
  }


  public function getImageList($goedkeuring)
  {

    global $wpdb;
    $return_array = array();

    $result_array = $wpdb->get_results("SELECT * FROM `" . $wpdb->prefix . "isw_afbeeldingen` WHERE `goedkeuring` = '$goedkeuring' ORDER BY `ID_afbeelding`", ARRAY_A);

    // For all database results:
    foreach ($result_array as $idx => $array) {
      // connect to SetAndGet file and create a new class
      $Imageprocesser = new Image_processer();
      // Set all info
      $Imageprocesser->setId($array['ID_afbeelding']);
      $Imageprocesser->setNaam($array['afbeelding_naam']);
      $Imageprocesser->setAfbeelding($array['afbeelding_link']);
      $Imageprocesser->setCategorie($array['FK_ID_categorie']);
      $Imageprocesser->setGoedkeuring($array['goedkeuring']);

      // Add new object toe return array.
      $return_array[] = $Imageprocesser;
    }
    return $return_array;
  }


  /**
  *
  * @global type $wpdb The Wordpress database class
  * @param type $input_array containing delete id
  * @return boolean TRUE on succes OR FALSE
  */
  public function delete($input_array){

    try {
      // Check input id
      if (!isset($input_array['id']) )
      throw new Exception(__("Missing mandatory fields") );
      global $wpdb;
      // Delete row by provided id (Wordpress style)
      $wpdb->delete( $this->getTableName(),
      array( 'ID_afbeelding' => $input_array['id'] ),
      array( '%d' ) ); // Where format
      $image_link = CURSUS_PLUGIN_INCLUDES_IMGS_DIR . '/uploads/' . $input_array['link'];
      // plugins_url() . '/' . CURSUS_PLUGIN_NAME
      //*/

      // Error ? It's in there:
      if ( !empty($wpdb->last_error) ){

        throw new Exception( $wpdb->last_error);
      }


    } catch (Exception $exc) {
      // @todo: Add error handling
      echo '<pre>';
      $this->last_error = $exc->getMessage();
      echo $exc->getTraceAsString();
      echo $exc->getMessage();
      echo '</pre>';
    }
    if (file_exists($image_link)) {
      unlink("$image_link");
    }
  }

  /**
  *
  * @global type $wpdb The WordPress database class
  * @param type $input_array containing insert data
  * @return boolean TRUE on succes OR FALSE
  */

  public function save($input_array, $goedkeuring){
    try {
      if (!isset($input_array['afbeelding_naam']) OR !isset($input_array['fileToUpload']) OR !isset($input_array['categorie'])){
        // Mandatory fields are missing
        throw new Exception(__("Missing mandatory fields"));
      }

      if ((strlen($input_array['afbeelding_naam']) < 1) OR (strlen($input_array['fileToUpload']) < 1) OR (strlen($input_array['categorie']) < 1)) {
        // Mandatory fields are empty
        throw new Exception( __("Empty mandatory fields") );
      }

      global $wpdb;
      // Insert query
      $wpdb->query($wpdb->prepare("INSERT INTO `" . $wpdb->prefix
        . "isw_afbeeldingen` (`afbeelding_naam`, `afbeelding_link`, `FK_ID_categorie`, `goedkeuring`)".
        " VALUES ( '%s', '%s', '%s', '%s');",
        $input_array['afbeelding_naam'], $input_array['fileToUpload'], $input_array['categorie'], $goedkeuring));

        // var_dump($wpdb);
        // Error ? It's in there:
        if (!empty($wpdb->last_error)) {
          $this->last_error = $wpdb->last_error;
        }
        /*
        echo '<pre>';
        echo __FILE__.__LINE__.'<br />';
        return var_dump($wpdb);
        echo '</pre>';
        die;

        /**/

        //echo 'Insert name and description for this Category:"'.$input_array['name'].
        //        '"-"'. $input_array['description'].'"<br />';

      } catch (Exception $exc) {
        // @todo: Add error handling
        echo '<pre>'. $exc->getTraceAsString() .'</pre>';
      }
      return TRUE;
    }

    Public function ImageLinkAndSaver($post_array) {
      $target_dir = CURSUS_PLUGIN_INCLUDES_IMGS_DIR . "/uploads/";
      $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
      $uploadOk = 1;
      $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
      // Check if image file is a actual image or fake image
      if(isset($_POST["submit"])) {
        $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
        if($check !== false) {
          $check = "File is an image - " . $check["mime"] . ".";
          $uploadOk = 1;
        } else {
          $MessageErrorOrNot = "File is not an image.";
          $uploadOk = 0;
        }
      }
      // Check if file already exists
      if (file_exists($target_file)) {
        echo "Sorry, file already exists.";
        $uploadOk = 0;
      }
      // Check file size
      if ($_FILES["fileToUpload"]["size"] > 500000) {
        $check = "Sorry, your file is too large.";
        $uploadOk = 0;
      }
      // Allow certain file formats
      if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
      && $imageFileType != "gif" ) {
        $check = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
      }
      // Check if $uploadOk is set to 0 by an error
      if ($uploadOk == 0) {
        $check = "Sorry, your file was not uploaded.";
        // if everything is ok, try to upload file
      } else {
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
          $check = "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
          return TRUE;
        } else {
          $check = "Sorry, there was an error uploading your file.";
        }
      }
    }
  }
