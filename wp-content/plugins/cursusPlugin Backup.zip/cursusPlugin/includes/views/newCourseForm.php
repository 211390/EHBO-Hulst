<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
</style>
<?php

// Include model:
include CURSUS_PLUGIN_MODEL_DIR. "/newCourseRegistration_processor.php";

// Declare class variable:
$Image_processer = new Image_processer();

// Set base url to current file and add page specific vars
// If provided set current file based on the provided link
$current_file = (!empty($get_inputs['link']) ?
  MY_EVENT_ORGANISER_PLUGIN_INCLUDES_VIEWS_DIR. '/'. $get_inputs['link'].'.php' :
'');
// Add the current page link get param.
if (!empty($get_inputs['link'])){
 $params = array( 'link' => $get_inputs['link']);
 $file_base_url = add_query_arg( $params, $base_url );

} else {
 // Or stick to base url
 $file_base_url = $base_url;
}

// Get the GET data in filtered array
$get_array = $Image_processer->getGetValues();

// Keep track of current action.
$action = FALSE;
if (!empty($get_array)){
  // Check actions
  if (isset($get_array['action'])){
    $action = $Image_processer->handleGetAction($get_array);
  }
}

// Get the POST data in filtered array
$post_array = $Image_processer->getPostValues();

// Collect Errors
$error = FALSE;

// Check the POST data
if (!empty($post_array)){
  // Check the add form:
  $post_array['fileToUpload'] = $_FILES['fileToUpload']['name'];
  $add = FALSE;
  if (isset($post_array['submit']) ){
    // Save event categorie
    $result = $Image_processer->ImageLinkAndSaver($post_array);
    if($result == TRUE) {
      $save = $Image_processer->save($post_array, 0);
    }
    if ($check){
      // Save was succesfull
      $add = TRUE;
      echo $check;
    } else {
      // Indicate error
      $error = TRUE;
      echo $check;
    }
  }
}

?>

<html>
<head>
  <style>
  img {
    width:100px;
    height:100px;
  }
  </style>
</head>
<body>

  <form action="<?php //echo $file_base_url; ?>" method="post" enctype="multipart/form-data">
    <input type="text" name="afbeelding_naam" id="afbeelding_naam"></input>
    <input type="file" name="fileToUpload" id="fileToUpload">
    <select name="categorie">
    <?php
    $cat = $Image_processer->getCatList();

    foreach($cat as $cat_single) {
    ?>

      <option value="<?php echo $cat_single->getId(); ?>"><?php echo $cat_single->getName(); ?></option>

    <?php
  }
    ?>
    </select>
    <input type="submit" value="Upload Image" name="submit">
  </form>
</body>
</html>

<?php
$form_reciever = 1;

include CURSUS_PLUGIN_INCLUDES_VIEWS_DIR. '/image_slider.php';

?>
