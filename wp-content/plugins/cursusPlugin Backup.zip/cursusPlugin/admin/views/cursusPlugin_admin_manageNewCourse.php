<style>
table, th, td {
  border-collapse: collapse;
}

.thead {
  border: 1px solid black;
  height:30px;
}

.thead td {
height: 65px;
text-align: center;
}

.thead input {
  margin-right:50px;
}

.thead select {
  margin-right:50px;
}

.data_table td {
  border: 1px solid black;
  text-align:center;
}

</style>
<?php

// Include model:
include CURSUS_PLUGIN_MODEL_DIR. "/Image_proccesser_addon.php";

// Declare class variable:
$Image_processer = new image_proccessor_addon();


// Set base url to current file and add page specific vars
$base_url = get_admin_url().'admin.php';
$params = array( 'page' => basename(__FILE__,".php"));

// Add params to base url
$base_url = add_query_arg( $params, $base_url );

// Get the GET data in filtered array
$get_array = $Image_processer->getGetValues();

// Keep track of current action.
$action = FALSE;
if (!empty($get_array)){
  // Check actions
  if (isset($get_array['action'])){
    $action = $Image_processer->handleGetAction($get_array);
  }
}
// Get the POST data in filtered array
$post_array = $Image_processer->getPostValues();

// Collect Errors
$error = FALSE;

// Check the POST data
if (!empty($post_array)){
   var_dump('1');
 // Check the update form:
 if (isset($post_array['update']) ){
 // Save event categorie
 var_dump('2');
 $Image_processer->update($post_array);
 }
}
?>

<html>
<head>
  <style>
  img {
    width:100px;
    height:100px;
  }
  </style>
</head>
<body>
<?php echo (($action == 'update') ? '<form action="' . $base_url . '"method="post">' : '');
?>
  <table style="width:50%">
    <?php
    if ($Image_processer->getNrofImages("0")) {
      ?>
      <tr><td colspan="3">er zijn geen images om goed te keuren</tr>
        <?php
      } else {

        // load all list of images
        $image_list = $Image_processer->getImageList("0");
        //var_dump($image_list);

        foreach($image_list as $image_single) {
          // update
          $params = array( 'action' => 'update', 'id' => $image_single->getId(), 'goedkeuring' => '1');
          // Add params to base url update link
          $upd_link = add_query_arg( $params, $base_url );
          // Create delete link
          $params = array( 'action' => 'delete', 'id' => $image_single->getId(), 'link' => $image_single->getAfbeelding());
          // Add params to base url delete link
          $del_link = add_query_arg( $params, $base_url );

          $image_link = plugins_url() . '/' . CURSUS_PLUGIN_NAME . '/includes/images/uploads/' . $image_single->getAfbeelding();
          // echo $image_link;

          if ( ($action == 'update') &&
          ($image_single->getId() == $get_array['id']) ){
          ?>
          <?php
          echo "<td>" . "<img src='$image_link'/> <br>" . "</td>";
          ?>
          <td width="180"><input type="hidden" name="id" value="<?php echo $image_single->getId(); ?>">
                          <input type="text" name="afbeelding_naam" value="<?php echo $image_single->getNaam(); ?>"></td>
          <td width="200"><select name="categorie">
          <?php
          $cat = $Image_processer->getCatList();

          foreach($cat as $cat_single) {
          ?>

            <option value="<?php echo $cat_single->getId(); ?>"><?php echo $cat_single->getName(); ?></option>

          <?php
          }
          ?>
          </select></td>
          <td width="200"><input type="hidden" name="goedkeuring" value ="1">
          <input type="submit" name="update" value="toevoegen"/></td>
          <?php
            } else {
              ?>
              <tr>
              <?php echo "<td>" . $image_single->getNaam() . "</td>"; ?> <br>
              <?php
              echo "<td>" . "<img src='$image_link'/> <br>" . "</td>";
              ?>

              <?php
              $cat = $Image_processer->getCurrentCatList($image_single->getCategorie());
              foreach($cat as $cat_single) {
                echo "<td>" . $cat_single->getName() . "</td> <br>";
              }
               ?> <br>

              <?php  echo "<td><a href='$upd_link'>toestaan</a></td>"; ?>
              <?php  echo "<td><a href='$del_link'>verwijderen</a></td>"; ?>
              <tr>
              <?php

            }
            }
            }
            echo (($action == 'update' ) ? '</form>' : '');
          ?>
        </table>
</body>
</html>
