<style>
table, th, td {
  border-collapse: collapse;
}

.thead {
  border: 1px solid black;
  height:30px;
}

.thead td {
height: 65px;
text-align: center;
}

.thead input {
  margin-right:50px;
}

.thead select {
  margin-right:50px;
}

.data_table td {
  border: 1px solid black;
  text-align:center;
}

</style>
<?php

// Include model:
include CURSUS_PLUGIN_MODEL_DIR. "/newCourseRegistration_processor.php";

// Declare class variable:
$Image_processer = new Image_processer();

// Set base url to current file and add page specific vars
$base_url = get_admin_url().'admin.php';
$params = array( 'page' => basename(__FILE__,".php"));

// Add params to base url
$base_url = add_query_arg( $params, $base_url );

// Get the GET data in filtered array
$get_array = $Image_processer->getGetValues();

// Keep track of current action.
$action = FALSE;
if (!empty($get_array)){
  // Check actions
  if (isset($get_array['action'])){
    $action = $Image_processer->handleGetAction($get_array);
  }
}

// Get the POST data in filtered array
$post_array = $Image_processer->getPostValues();

// Collect Errors
$error = FALSE;

// Check the POST data
if (!empty($post_array)){
  // Check the add form:
  $post_array['fileToUpload'] = $_FILES['fileToUpload']['name'];
  $add = FALSE;
  if (isset($post_array['submit']) ){
    // Save event categorie
    $result = $Image_processer->ImageLinkAndSaver($post_array);
    if($result == TRUE) {
      $save = $Image_processer->save($post_array, 1);
    }
    if ($check){
      // Save was succesfull
      $add = TRUE;
      echo $check;
    } else {
      // Indicate error
      $error = TRUE;
      echo $check;
    }
  }
}
// var_dump($post_array);
// var_dump($wpdb)
?>

<html>
<head>
  <style>
  img {
    width:100px;
    height:100px;
  }
  </style>
</head>
<body>
<table style="width:75%">
  <tr class="thead">
  <form action="<?php echo $base_url; ?>" method="post" enctype="multipart/form-data">
    <td colspan="5"><input type="text" name="afbeelding_naam" id="afbeelding_naam"></input>
    <input type="file" name="fileToUpload" id="fileToUpload">
    <select name="categorie">
    <?php
    $cat = $Image_processer->getCatList();

    foreach($cat as $cat_single) {
    ?>

      <option value="<?php echo $cat_single->getId(); ?>"><?php echo $cat_single->getName(); ?></option>

    <?php
    }
    ?>
    </select>
    <input type="hidden" name="goedkeuring" id="goedkeuring" value="1"></input>
    <input type="submit" value="Upload Image" name="submit"></td>
  </tr>
  </form>
    <?php
    if ($Image_processer->getNrofImages("1")) {
      ?>
      <tr><td colspan="5">er zijn nog geen images toegevoegt, voer er een toe of keur een image goed</tr>
        <?php
      } else {

        // load all list of images
        $image_list = $Image_processer->getImageList("1");
        // load all the categories
        $cat = $Image_processer->getCatList();


        foreach($image_list as $image_single) {

          // Create delete link
          $params = array( 'action' => 'delete', 'id' => $image_single->getId(), 'link' => $image_single->getAfbeelding());
          // Add params to base url delete link
          $del_link = add_query_arg( $params, $base_url );

          $image_link = plugins_url() . '/' . CURSUS_PLUGIN_NAME . '/includes/images/uploads/' . $image_single->getAfbeelding();
          // echo $image_link;
          ?>
          <tr class="data_table">
            <?php echo "<td>" . $image_single->getId() . "</td>"; ?>
            <?php echo "<td>" . $image_single->getNaam() . "</td>"; ?>
            <?php echo "<td>" . "<img src='$image_link'/> " . "</td>"; ?>
            <?php
            $cat = $Image_processer->getCurrentCatList($image_single->getCategorie());
            foreach($cat as $cat_single) {
              echo "<td>" . $cat_single->getName() . "</td> ";
            }
            ?>

            <?php  echo "<td><a href='$del_link'>Delete</a></td>"; ?>
            <tr>
              <?php
            }
          }
          ?>
        </table>
</body>
</html>
