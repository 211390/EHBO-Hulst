<?php
/**
 * This Admin controller file provide functionality for the Admin section of the My event organiser.
 *
 * @author < your name >
 * @version 0.1
 *
 */

class cursusPlugin_adminController
{
    /**
     * This function will prepare all Admin functionality for the plugin
     */
    static function prepare()
    {
        // Check that we are in the admin area
        if (is_admin()) :

            // Add the sidebar Menu structure
            add_action('admin_menu', array('cursusPlugin_adminController', 'addMenus'));

        endif;
    }
    /**
     * Add the Menu structure to the Admin sidebar
     */
    static function addMenus()
    {
        add_menu_page(
            __('Cursus Plug-in Admin', 'cursusPlugin'), // Header text
            __('Cursus Plug-in Admin', 'cursusPlugin'), //Menu name
            '', //capabillity which is required to show menu.
            'cursus_plug-in_admin', // menu slug
            array('cursusPlugin_adminController', 'adminMenuPage'), //array(name of controller, static function)
            'dashicons-heart' //dashicon
        );
        // sub menu toevoevoegen
        add_submenu_page(
            'cursus_plug-in_admin', //name of main menu slug
            __('Aanmaken Nieuwe Cursus', 'cursusPlugin'), // Header text
            __('Aanmaken Nieuwe Cursus', 'cursusPlugin'), //Menu name
            'manage_options', //capability which is required to show menu
            'aanmaken-nieuwe-cursus', //menu slug
            array('cursusPlugin_AdminController', 'adminSubMenuNieuwAanmaken') //array(name of controller, static function)
        );
        // sub menu toevoevoegen
        add_submenu_page(
            'cursus_plug-in_admin', //name of main menu slug
            __('Beheren Nieuwe Cursus', 'cursusPlugin'), // Header text
            __('Beheren Nieuwe Cursus', 'cursusPlugin'), //Menu name
            'manage_options', //capability which is required to show menu
            'beheren-nieuwe-cursus', //menu slug
            array('cursusPlugin_AdminController', 'adminSubMenuNieuwBeheren') //array(name of controller, static function)
        );
    }
        /**
         * The main menu page
         */
        static function adminMenuPage()
        {
            // Include the view for this menu page.
            include CURSUS_PLUGIN_ADMIN_VIEWS_DIR .
                '/admin_main.php';
        }
        /**
         * The submenu pages for the creation and managing of the 'Cursus Plug-in'.
         */
        static function adminSubMenuNieuwAanmaken()
        {
            // include the view for the 'Reden Uitleg Editor' submenu page.
            include CURSUS_PLUGIN_ADMIN_VIEWS_DIR .
                '/cursusPlugin_admin_createNewCourse.php';
        }

        static function adminSubMenuNieuwBeheren()
        {
            // includes the view for the 'Infoknop Editor' submenu page.
            include CURSUS_PLUGIN_ADMIN_VIEWS_DIR .
                '/cursusPlugin_admin_manageNewCourse.php';
        }
    }
