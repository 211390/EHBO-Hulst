<?php
defined('ABSPATH') OR exit;

/**
 * Plugin Name: EHBO Hulst | Cursus Plug-in
 * Plugin URI: https://stichtingivs.nl/
 * Description: Een plug-in voor het aanmaken en beheren van cursussen voor op de programma pagina.
 * Author: IVS (Innovision Solutions)
 * Author URI: https://stichtingivs.nl/
 * Version: 0.0.1
 * Text Domain: cursusPlugin
 * Domain Path: languages
 *
 */

// Define the plugin name:
define('CURSUS_PLUGIN', __FILE__);

// Include the general definition file:
require_once plugin_dir_path(__FILE__) . 'includes/defs.php';


/* Register the hooks */
register_activation_hook(__FILE__, array('CursusPlugin', 'on_activation'));

register_deactivation_hook( __FILE__, array( 'CursusPlugin','on_deactivation' ) );

class CursusPlugin
{

    public function __construct()
    {

        // Fire a hook before the class is setup.
        do_action('CURSUS_PLUGIN_pre_init');

        // Load the plugin.
        add_action('init', array($this, 'init'), 1);

    }

    public static function on_activation() {

        if ( ! current_user_can( 'activate_plugins' ) )
            return;
        $plugin = isset( $_REQUEST['plugin'] ) ? $_REQUEST['plugin'] : '';
        check_admin_referer( "activate-plugin_{$plugin}" );
        // Create the DB
        CursusPlugin::createDb();

    }

    public static function on_deactivation()
    {
        if ( ! current_user_can( 'activate_plugins' ) )
            return;
        $plugin = isset( $_REQUEST['plugin'] ) ? $_REQUEST['plugin'] : '';
        check_admin_referer( "deactivate-plugin_{$plugin}" );
    }

    /**
     * Loads the plugin into WordPress.
     *
     * @since 1.0.0
     */
    public function init()
    {
        // Run hook once Plugin has been initialized.
        do_action('CURSUS_PLUGIN_init');

        // Load admin only components.
        if (is_admin()) {

            // Load all admin specific includes
            $this->requireAdmin();

            // Setup admin page
            $this->createAdmin();
        }
        // Load the view shortcodes
        $this->loadViews();
    }

    /**
     * Loads all admin related files into scope.
     *
     * @since 1.0.0
     */
    public function requireAdmin()
    {
// Admin controller file
        require_once CURSUS_PLUGIN_ADMIN_DIR . '/cursusPlugin_adminController.php';
    }
/**
 * Admin controller functionality
 */
public function createAdmin()
    {
        cursusPlugin_adminController::prepare();
    }

/**
 * Load the view shortcodes:
 */
 public function loadViews()
    {

        include CURSUS_PLUGIN_INCLUDES_VIEWS_DIR . '/view_shortcodes.php';

    }
/**
 * Generate database tables
 */

public static function createDb() {

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    //Calling $wpdb;
    global $wpdb;

    $charset_collate = $wpdb->get_charset_collate();

    //Names of the tables that will be added to the db
    $stageplaats = $wpdb->prefix . "SPA_stageplaats";


    //Create the stageplaats table
    $sql = "CREATE TABLE IF NOT EXISTS $stageplaats (
    id INT NOT NULL AUTO_INCREMENT,
    stageplaats VARCHAR(1024) NOT NULL,
    locatie VARCHAR(1024) NOT NULL,
    email VARCHAR(255) NOT NULL,
    aantal_plekken INT NOT NULL,
    opmerking VARCHAR(1024) NOT NULL,
    PRIMARY KEY  (id))
    ENGINE = InnoDB $charset_collate";
    dbDelta($sql);
    }
}

// Instantiate the class
$CursusPlugin = new CursusPlugin();

?>